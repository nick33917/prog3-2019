<?php
 class Proveedor
 {
    public $id;
    public $nombre;
    public $email;
    public $foto;

    public function __construct($id1, $nombre1, $email1, $foto1)
    {
        $this->id = $id1;
        $this->nombre = $nombre1;
        $this->email = $email1;
        $this->foto= $foto1;

    }
    public static function LeerArchivo()
    {
        $arrayProveedores = array();
        if(file_exists("proveedores.txt"))
        {
            $file = fopen("proveedores.txt", "r");
            while(!feof($file))
            {
                $datos= explode(",",fgets($file));
                if($datos[0]!=null)
                {
                    $prov = new Proveedor($datos[0],$datos[1],$datos[2],$datos[3]);
                    array_push($arrayProveedores,$prov);

                }
            }
            fclose($file);
            return $arrayProveedores;
        }

    }

    public static function CargarProveedor()
    {
        $id=$_POST['id'];
        $nombre=$_POST['nombre'];
        $email=$_POST['email'];
        $foto = $_FILES['foto']["tmp_name"];

        $extension = explode(".",$_FILES["foto"]["name"]);
        $pathNuevo = "Fotos/". $id.".". $nombre .".". $extension[1];
        move_uploaded_file($foto,$pathNuevo);

        if(file_exists("proveedores.txt"))
        {
            $file = fopen("proveedores.txt", "a");

            fwrite($file, "$id,$nombre,$email,$id.$nombre.$extension[1] \r\n");

            fclose($file);
        }
        else
        {
            $file = fopen("proveedores.txt", "w");

            fwrite($file, "$id,$nombre,$email,$id.$nombre.$extension[1] \r\n");

            fclose($file);
        }
    }

    public static function ConsultarProveedor()
    {
        $flag = true;
        $nombre=$_GET['nombre'];
        $arrayProveedores = array();
        if(file_exists("proveedores.txt"))
        {
            $file = fopen("proveedores.txt", "r");
            while(!feof($file))
            {
                $datos= explode(",",fgets($file));
                if($datos[0]!=null)
                {
                    $prov = new Proveedor($datos[0],$datos[1],$datos[2],$datos[3]);
                    array_push($arrayProveedores,$prov);

                }
            }
            fclose($file);
        }

        foreach($arrayProveedores as $provee)
        {
            if($provee->nombre == $nombre)
            {
                var_dump($provee);
                $flag = false;
                break;
            }
        }
        if($flag)
        {
           echo "No existe el proveedor ".$nombre;
        }
    }

    public static function ListarProveedores()
    {
        $arrayProveedores = array();
        if(file_exists("proveedores.txt"))
        {
            $file = fopen("proveedores.txt", "r");
            while(!feof($file))
            {
                $datos= explode(",",fgets($file));
                if($datos[0]!=null)
                {
                    $prov = new Proveedor($datos[0],$datos[1],$datos[2],$datos[3]);
                    array_push($arrayProveedores,$prov);
                }
            }
        }
        var_dump($arrayProveedores);

    }
}
?>