<?php
include_once "proveedor.php";
class Pedido
{
    public $producto;
    public $cantidad;
    public $idProveedor;

    public function __construct($producto1, $cantidad1, $idProveedor1)
    {
        $this->producto = $producto1;
        $this->cantidad = $cantidad1;
        $this->idProveedor = $idProveedor1;

    }
    public static function leerArchivo()
    {
        $arrayPedidos = array();
        if(file_exists("pedidos.txt"))
        {
            $file = fopen("pedidos.txt", "r");
            while(!feof($file))
            {
                $datos= explode(",",fgets($file));
                if($datos[0]!=null)
                {
                    $ped = new Pedido($datos[0],$datos[1],$datos[2]);
                    array_push($arrayPedidos,$ped);
                }
            }
            fclose($file);
            return $arrayPedidos;
        }
    }

    public static function GuardarPedido()
    {
        $flag=false;
        $arrayProv=Proveedor::LeerArchivo();
        $idProv=$_POST['idProveedor'];
        $produc=$_POST['producto'];
        $cant=$_POST['cantidad'];
        foreach($arrayProv as $prov)
        {
            if($prov->id == $idProv)
            {
                $flag=true;
                break;
            }
        }

        if(file_exists("pedidos.txt"))
        {
            if($flag)
            {
                $file = fopen("pedidos.txt", "a");

                fwrite($file, "$produc,$cant,$idProv\r\n");

                fclose($file);
            }
            else
            {
                echo "No existe el id Del Proveedor";
            }
        }
        else
        {
            if($flag)
            {
                $file = fopen("pedidos.txt", "w");

                fwrite($file, "$produc,$cant,$idProv\r\n");

                fclose($file);
            }
            else
            {
                echo "No existe el id Del Proveedor";
            }
        }
    }

    public static function HacerPedido()
    {
        Pedido::GuardarPedido();
    }

    public static function ListarPedidos()
    {
        $pedidos = Pedido::leerArchivo();
        $proveedores = Proveedor::leerArchivo();

        foreach($pedidos as $ped)
        {
            $nom;
            foreach($proveedores as $prov)
            {
                if((int)$prov->id == (int)$ped->idProveedor)
                {
                    $nom = $prov->nombre;
                    break;
                }
            }

            echo "Producto:" . $ped->producto . " Cantidad:". $ped->cantidad ." IdProv:" . $ped->idProveedor ."Nombre:" . $nom ."\n";
        }
    }

    public static function ListarPedidoProveedor()
    {
        $pedidos = Pedido::leerArchivo();
        $id = $_GET['id'];
        foreach($pedidos as $ped)
        {
            if((int)$ped->idProveedor == $id)
            {
                echo "Producto:" . $ped->producto . " Cantidad:". $ped->cantidad . "\n";
            }
        }


    }
}
?>